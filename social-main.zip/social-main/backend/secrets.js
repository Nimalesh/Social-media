module.exports = {
  dbURI: 'mongodb+srv://social:social@social.qob6w.mongodb.net/myFirstDatabase?retryWrites=true&w=majority',
};
