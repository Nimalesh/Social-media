import React from 'react';

import AppWithRouter from './AppWithRouter';

const App = () => <AppWithRouter />;

export default App;
